package PARQUEADERO;

public class Vehiculo {
    private String placa;
    public String modelo;
    public String color;

    public Vehiculo(String placa, String modelo, String color) {
        this.placa = placa;
        this.modelo = modelo;
        this.color = color;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String toString() {
        return "Vehiculo{placa='" + placa + "', modelo='" + modelo + "', color='" + color + "'}";
    }
}
