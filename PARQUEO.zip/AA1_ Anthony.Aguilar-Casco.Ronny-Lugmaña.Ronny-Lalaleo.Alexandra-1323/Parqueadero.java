package PARQUEADERO;

import java.util.ArrayList;
import java.util.List;

public class Parqueadero {
    public List<Vehiculo> vehiculos;

    public Parqueadero() {
        vehiculos = new ArrayList<>();
    }

    public boolean registrarVehiculo(String placa, String modelo, String color) {
        for (Vehiculo v : vehiculos) {
            if (v.getPlaca().equals(placa)) {
                System.out.println("Ya existe un vehiculo con esta placa.");
                return false;
            }
        }
        vehiculos.add(new Vehiculo(placa, modelo, color));
        return true;
    }

    public Vehiculo consultarVehiculo(String placa) {
        for (Vehiculo v : vehiculos) {
            if (v.getPlaca().equals(placa)) {
                return v;
            }
        }
        return null;
    }

    public boolean actualizarVehiculo(String placa, String modelo, String color) {
        Vehiculo v = consultarVehiculo(placa);
        if (v != null) {
            v.modelo = modelo;
            v.color = color;
            return true;
        }
        return false;
    }

    public boolean eliminarVehiculo(String placa) {
        Vehiculo v = consultarVehiculo(placa);
        if (v != null) {
            vehiculos.remove(v);
            return true;
        }
        return false;
    }

    public void mostrarVehiculos() {
        if (vehiculos.isEmpty()) {
            System.out.println("No hay vehiculos registrados.");
        } else {
            for (Vehiculo v : vehiculos) {
                System.out.println(v);
            }
        }
    }
}
