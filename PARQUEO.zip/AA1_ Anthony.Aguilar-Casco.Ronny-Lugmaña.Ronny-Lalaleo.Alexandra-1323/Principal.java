package PARQUEADERO;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Parqueadero parqueadero = new Parqueadero();
        int opcion;

        do {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Registrar vehiculo");
            System.out.println("2. Consultar vehiculo");
            System.out.println("3. Actualizar vehiculo");
            System.out.println("4. Eliminar vehiculo");
            System.out.println("5. Mostrar todos los vehiculos");
            System.out.println("6. Salir");
            System.out.print("Elige una opcion: ");
            opcion = sc.nextInt();
            sc.nextLine(); // Consumir salto de linea

            switch (opcion) {
                case 1:
                    System.out.print("Ingresa la placa: ");
                    String placa = sc.nextLine();
                    System.out.print("Ingresa el modelo: ");
                    String modelo = sc.nextLine();
                    System.out.print("Ingresa el color: ");
                    String color = sc.nextLine();
                    if (parqueadero.registrarVehiculo(placa, modelo, color)) {
                        System.out.println("Vehiculo registrado correctamente.");
                    }
                    break;
                case 2:
                    System.out.print("Ingresa la placa del vehiculo a consultar: ");
                    placa = sc.nextLine();
                    Vehiculo v = parqueadero.consultarVehiculo(placa);
                    if (v != null) {
                        System.out.println("Vehiculo encontrado: " + v);
                    } else {
                        System.out.println("No se encontro un vehiculo con esa placa.");
                    }
                    break;
                case 3:
                    System.out.print("Ingresa la placa del vehiculo a actualizar: ");
                    placa = sc.nextLine();
                    System.out.print("Ingresa el nuevo modelo: ");
                    modelo = sc.nextLine();
                    System.out.print("Ingresa el nuevo color: ");
                    color = sc.nextLine();
                    if (parqueadero.actualizarVehiculo(placa, modelo, color)) {
                        System.out.println("Vehiculo actualizado correctamente.");
                    } else {
                        System.out.println("No se encontro un vehiculo con esa placa.");
                    }
                    break;
                case 4:
                    System.out.print("Ingresa la placa del vehiculo a eliminar: ");
                    placa = sc.nextLine();
                    if (parqueadero.eliminarVehiculo(placa)) {
                        System.out.println("Vehiculo eliminado correctamente.");
                    } else {
                        System.out.println("No se encontro un vehiculo con esa placa.");
                    }
                    break;
                case 5:
                    System.out.println("\n--- Lista de Vehiculos ---");
                    parqueadero.mostrarVehiculos();
                    break;
                case 6:
                    System.out.println("Saliendo del programa.");
                    break;
                default:
                    System.out.println("Opcion no valida.");
            }
        } while (opcion != 6);

        sc.close();
    }
}

